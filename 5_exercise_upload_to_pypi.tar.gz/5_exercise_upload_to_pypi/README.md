#Summary of this package
#Create Gaussian and Binomial 