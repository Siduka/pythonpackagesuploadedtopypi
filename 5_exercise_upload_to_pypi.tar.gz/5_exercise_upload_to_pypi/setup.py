from setuptools import setup

setup(name='gbds_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['gbds_distributions'],
      zip_safe=False)
